# Result

## For the "Dominos Computer" Video
### T5 Small
| ID  | Summary Text |
|:---:|:-------------|
| 0   | Doesn't use batteries, but takes a hell of a long time to program: How do I run Windows 10 on it? |
| 1   | Think of using insulator for conductors such as walls : Isolating material for DominoBSD? I'd like to patch KDE2 for DominoBBSD |
| 2   | Intel, Amd shrinking down there transistor architecture to fit more transistors: i'm a 'disease shrink' |
| 3   | I am so clumsy if I were the girl who walked into the set, I would have knocked them all down |
| 4   | Who boo'd is a real chad на отравила ему иру 28? |
| 5   | Maybe use insulator for conductor such as walls: I'd say it anyway: Dominoes :-) Is it worth it? |
| 6   | You probably don't want to: на отравила ему иру 28, ли они какое-то |

### T5 Base
| ID  | Summary Text |
|:---:|:-------------|
| 0   | Doesn't use batteries, but takes a hell of a long time to program: Is it 4 bit or 5 bit? |
| 1   | How do I patch KDE2 for DominoBSD? What is the 'stuff' that I need to fix this time? |
| 2   | Why do Intel, Amd shrink their transistors to fit more transistors? i don't have patience: Xinhai |
| 3   | I was like oh shit if i were the girl I would have a vagina: Matt & Co. |
| 4   | That one guy who boo'd is a real chad на отравила ему иру 28? |
| 5   | Maybe use insulator for conductor like walls: I'm not the first to think of it: YES, yay! |
| 6   | You probably don't want to: на отравила ему иру 28, тое вала 28? |

### BART
| ID  | Summary Text |
|:---:|:-------------|
| 0   | What are the features of the 2nd computer? |
| 1   | Perhaps consider using insulator for conductor such as walls? |
| 2   | What is the problem Intel and Amd Have when they are shrinking? |
| 3   | I would have knocked them all down if I was the girl: Matt |
| 4   | What is the definition of 'boooooring as fuck'? |
| 5   | Perhaps consider using insulator for the conductor such as walls? |
| 6   | What is цифру 28?  Или |

## For the "Quiz" Video
### T5 Small
| ID  | Summary Text |
|:---:|:-------------|
| 0   | If I don't take my meds first thing when I get up, I can still be tired. I'm ready to be on sleep mode by the time I feed kids |
| 1   | If I don't take my meds first thing when I get up, I can still be tired. I'm ready to be on sleep mode by the time I feed kids |
| 2   | Don't take my meds first thing when I get up, I can still be tired: Isn't it a bad thing? |
| 3   | I can still be very tired during the day if I don't take my meds first thing. I have no money resting bpm of 93: I wanna help |
| 4   | If I don't take my meds first thing when I get up, I can still be tired. I'm ready to be on sleep mode by the time I feed kids |
| 5   | Great sage grouse known as prairie chicken I knew spoonbill, saxoma. I knew the sages groused one cuz of a project in Washington |
| 6   | Don't take my meds first thing when I get up, it doesn't seem to metabolize: I'm on sleep mode |

### T5 Base
| ID  | Summary Text |
|:---:|:-------------|
| 0   | I'm very tired during the day if I don't take my meds first thing: YES, it's 93bpm |
| 1   | I'm very tired during the day if I don't take my meds first thing: Dr. Yin Xian |
| 2   | I'm still very tired during the day if I don't take my meds first: Is it a good idea? |
| 3   | My day starts at 5:00 a.m. most of the time, I'm on sleep mode: I wanna help. I have no money resting bpm of 93? Woman needs to talk to doctor |
| 4   | I'm very tired during the day if I don't take my meds first thing: Is Dropout a good deal? |
| 5   | I knew the spoonbill and the sage grouse: I'd like to see them up close. Dropout is one of the best unscripted TV shows out there |
| 6   | I'm very tired during the day if I don't take my meds first thing: I've been there: Ignore quota |

### BART
| ID  | Summary Text |
|:---:|:-------------|
| 0   | I'm extremely curious about what kind of medication I take |
| 1   | I'm extremely curious about what kind of medication I take |
| 2   | I'm extremely curious about what kind of medication I take |
| 3   | I'm extremely curious about what kind of medication I take |
| 4   | I'm extremely curious about what kind of medication I take |
| 5   | I knew the spoonbill and the sage grouse: Wikipedia |
| 6   | I'm extremely curious about what kind of medication I take |
